var index = {

    selectedApp: 32,

    init: function () {
        $("#31apps > div").hover(
            function () {},
            function () {
                index.selectApp(32);
            }
        );
    },

    selectApp: function(ndx) {
        ndx--;
        var left = (ndx % 16 * -700) + "px";
        var top = ((Math.floor(ndx / 16) * -200) - 10) + "px";
        selectedApp = ndx;
        $("#31apps div.itemDetail > table").animate({"marginTop": top, marginLeft: left},{queue:false, duration:1000, easing:"easeOutBack"});
    },

    getExamplesIconHtml: function() {
        var appgrid = "<table>";
        var day = 1;
        var max = 31;
        for (var i=0;i<2;i++) {
            appgrid += "<tr>";
            for (var j=0;j<16;j++) {
                if (day > max) {
                    appgrid += "<td class='empty'>";
                }
                else {
                    appgrid += "<td>";
                    appgrid += "<a id='xlnk" + day + "' href='javascript:void(0)' onclick='index.selectApp(" + day + ")'>";
                    appgrid += "<img src='assets/images/day" + day + "_icon_32.png'/>";
                    appgrid += "</a>";
                }

                day++;
                appgrid += "</td>";
            }

            appgrid += "</tr>";
        }
        
        appgrid += "</table>";
        return appgrid;
    }
}

$(function(){
    index.init();
});